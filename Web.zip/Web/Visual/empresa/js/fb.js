const searchFrom = document.querySelector('.search');
const input = document.querySelector('.input');
const newList = document.querySelector('.new-list');

searchFrom.addEventListener('submit', retrieve)

function retrieve(e){
/*
    if(input.value == ''){
        alert('Input field is empty!')
        return
    }
    newsList.innerHtml = ''
*/
    e.preventDefault()
    const apiKey = '9c0adaab56fb4995a7e53f40d5559b5e'
    let topic = input.value;
    let url= `https://newsapi.org/v2/everything?q=${topic}&apiKey=${apiKey}`
    
    fetch(url).then((res)=>{
        return res.json()
    }).then((data)=>{
        console.log(data)
        /*
        data.article.forEach(article =>{
            let li = document.createElement('li');
            let a = document.createElement('a');
            a.setAttribute('href', article.url);
            a.setAttribute('target', '_blank')
            a.textContent = article.title
            
            li.appendChild(a);
            newsList.appendChild(li);
            
            
        })
        .catch((error)=>{
            console.log(error)
        })*/
        
    })
    console.log(topic)
}