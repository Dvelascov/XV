var request = new XMLHttpRequest ();
var url="https://jsonplaceholder.typicode.com/photos"
var employee_name;
request.open ('GET',url);

request.send ();
request.onload = function(){
    var obj = JSON.parse(request.response);
    console.log(obj);
    
    var ul =document.getElementById('lista');

    for(var i=0; i<obj.length; i++){
        var li = document.createElement('li');
        li.className = "list-group-item";
        var s = obj[i];
        li.innerHTML =" Title: " + s.title + " //url: " + s.url + " //thumbnailUrl: " + s.thumbnailUrl;
        ul.appendChild(li);
    }

};
request.send();
