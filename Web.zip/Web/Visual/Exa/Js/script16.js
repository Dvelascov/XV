var arreglolista
var elemento
function Llenarlista(){
    for(var i=0; i<10; i++){
        elemento=prompt("Ingresa elemento de la lista");
        arreglolista[i]=elemento;
    }
}
function ImprimirLista(){
    for(var i=0; i<10; i++){
        console.log(arreglolista[i].TextContent);
    }
}
