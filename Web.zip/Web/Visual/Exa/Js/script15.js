var num1
var num2
var letras

function sumar_y_mostrar(){
    res = parseInt(num1) + parseInt(num2);
    alert("El resultado de la suma es: "+res);

}
function pedirDatos(){
    num1=prompt("Ingresa num1");
    num2=prompt("Ingresa num2");

}
function sumar_y_mostrar_P(n1,n2){
    res = parseInt(n1)+parseInt(n2);
    alert("El resultado es: "+res);

}
//function creamsj(){
    //var msj = "Mensaje de prueba"
//}

function letra(){
    letras = prompt("Dame una letra");

}
function esVocal(){
    alert(letras)
    switch(letras){
        case 'a':
            alert("Es vocal")
            break;
        case 'e':
            alert("Es vocal")
            break;
        case 'i':
            alert("Es vocal")
            break;
        case 'o':
            alert("Es vocal")
            break;
        case 'u':
            alert("Es vocal")
            break;
        default:
            alert("nop es vocal")
            break;
    }
}