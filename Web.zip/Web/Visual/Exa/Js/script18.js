
var rButtons = document.getElementsByName("fav_language")
//alert(parrafos[0].textContent);
//alert(parrafos.length);

for(var i=0; i<rButtons.length; i++){
    //alert(rButtons[i].hasAttribute("checked"));

    if(rButtons[i].checked)
        alert("El radiobutton seleccionado es: "+rButtons[i].value+" :) ");
    
}

