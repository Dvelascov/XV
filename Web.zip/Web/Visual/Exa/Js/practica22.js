var request = new XMLHttpRequest ();
var url="https://dummy.restapiexample.com/api/v1/employees"
var employee_name;
request.open ('GET',url);

request.send ();
request.onload = function(){
    //hacer algo con la info recibida

    var obj = JSON.parse(request.response);
    console.log(obj);
    console.log(obj.data);
    var data = obj.data;
    console.log(data);
    //var employee_name = data[0].employee_name;
    

    var ul =document.getElementById('lista');

    for(var i=0; i<data.length; i++){
    var li = document.createElement('li');
    li.className = "list-group-item";
    var s = data[i];
    li.innerHTML = s.employee_name + ": $" + s.employee_salary +", age: " + s.employee_age; 
    ul.appendChild(li);
    }
};
request.send();
