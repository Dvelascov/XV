var arreglo = ["manzana","sandia","platano","naranja"];

console.log(arreglo)
//alert(arreglo);

console.log(arreglo[0].toUpperCase())
console.log(arreglo[2].toLowerCase())
console.log(arreglo[3].charAt(0))

console.log(arreglo[0].indexOf('z'))
console.log(arreglo[1].indexOf('z'))
console.log(arreglo[2].lastIndexOf('a'))
console.log(arreglo[3].lastIndexOf('z'))

alert("Un arreglo es de size: "+arreglo.length);
alert("tu arreglo es de size: ".concat(arreglo.length));

var mensaje = "Hola mundo";
var porcion = mensaje.substring(2); // porcion = "la mundo"
console.log(porcion);
porcion = mensaje.substring(5,8); // porcion ="Mun"
console.log(porcion)
porcion = mensaje.substring(1.8); // porcion = "ola mun"
console.log(porcion);
porcion = mensaje.substring(3,4);// porcion = "a"
console.log(porcion)

var msj = "Hola mundo soy una cadena de texto";
var palabra = mensaje.split(" "); // palabra = ["Hola", "Mundo", "soy", "una", ... ];
alert(palabra);
var palabrasola = "Hola";
var letras = palabra.split(" "); // letras = ["H", "o", "l", "a"]
alert(letras);

var mensaje = palabras.join("-"); // mensaje = "holamundo" mensaje = array.join(" "); // mensaje = "hola mundo"
alert(mensaje);

var arreglo = ["manzana", "kiwi", "naranja", "mandarina"];
alert(arreglo)
arreglo - arreglo.pop();
arreglo - arreglo.shift();
arreglo.push("Platano");
arreglo.unshift("cereza")
alert(arreglo)
alert(arreglo.reverse())

var numer1 = 10; 
var numer2 = 0; 
if(isNaN(numer1/numer2))
{
    alert("La division no esta definida");

}
else{
    alert("la division es igual a "+ numer1/numer2);
}

var numero1 = 4564.34567;
numero1.toFixed(2);//4564.35
numero1.toFixed(6);//4564.345670
numero1.toFixed();//4564




