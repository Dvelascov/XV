document.getElementById("parrafo").textContent = "Bla bla Bla"

var parrafos = document.getElementsByTagName("p")
alert(parrafos[0].textContent);
alert(parrafos.length);

for(var i=0; i<parrafos.length; i++){
    alert(parrafos[i].textContent);
    var enlaces = parrafos[i].getElementsByTagName("a")
    for(var j=0; j<enlaces.length; j++){
        console.log(enlaces[j].textContent);
    }
}