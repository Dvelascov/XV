var request = new XMLHttpRequest();

var url = "http://dummy.restapiexample.com/api/v1/employees"
var employee_name;
request.open('GET', url);

request.send();
request.onload()=function(){
    //var object =JSON.parse(request.response)
    var obj =JSON.parse(request.response)
    console.log(obj);
    var data = obj.data
    console.log(data)
    var employee_name = data[0].employee_name; //para mostrar el primero data[0].employee_name
                                               //para mostrar todo data.employee_name


    console.log(employee_name)

};
request.send();



