function setData()
{
  
    localStorage.user="user";
     localStorage.password="123";
  
}
function validateUser(){
    if(localStorage.user==document.getElementById("login").value && localStorage.password==document.getElementById("password").value)
    window.location.assign("../html/Proyectos.html")
    
    else
    alert("datos incorrectos")
 
}