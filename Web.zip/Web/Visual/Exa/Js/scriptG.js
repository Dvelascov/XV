function setColors(opc, r, g, b){
    var boton = document.getElementById(opc)
    boton.setAttribute("style", 'background-color: rgb('+r+','+g+','+b+')')

}

function setGuess(){
    var rGuess = Math.round(Math.random() * (255-0));
    var gGuess = Math.round(Math.random() * (255-0));
    var bGuess = Math.round(Math.random() * (255-0));

    setRGBName(rGuess, gGuess, bGuess);
    var colorGuess = document.getElementById("colorGuess")
    colorGuess.setAttribute("style", 'background-color: rgb('+rGuess+','+gGuess+','+bGuess+')')
}

function setRGBName(r, g, b){
    var rgbName = document.getElementById("rgbName")
    rgbName.innerHTML = 'rgb('+r+','+g+','+b+')';
}