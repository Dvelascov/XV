
//alert("Hola mundo :D");
console.log("soy la consola... para que debuguees agusto :P")
var variable ='a'
//comentario
//alert("Linea de comentario :)");
/* bloque 
    de 
    comentario*/
//alert("Bloque de comentario :)");

var iva = 16; //variable tipo int
console.log(iva)
var total = 234.65 //var tipo decimal
console.log(total)
//cadenas de texto
var msj = 'Bienvenido';
console.log(msj)
var np = 'Producto abc';
console.log(np)
var text1 = "una frase con 'comillas simple' dentro";
console.log(text1)
var text2 = 'una frase con "comillas dobles" dentro';
console.log(text2)
text1 = 'una frase con \'comillas simple\' dentro';
console.log(text1)
text2 = "una frase con \"comillas dobles\" dentro";
console.log(text2)

//Array
var dias = ["Lunes", "Martes", "Miércoles", "Jueves",  "Viernes", "Sábado", "Domingo"];
var diaSeleccionado = dias[0]; // diaSeleccionado = "Lunes"
console.log(diaSeleccionado)
var otroDia = dias[5]; // diaSeleccionado = "Sabado"
console.log(otroDia)
//Booleanos
var clienteRegistrado = false;
var ivaIncluido = true;
console.log(clienteRegistrado)

//operadores
//asignacion
var numero1 = 3;
var numero2 = 0;
numero1 = numero2;
console.log(numero1)
//incremento y decremento
var numero = 5;
console.log(numero)
++numero;
console.log(numero)
--numero;
console.log(numero)
numero1++;
console.log(numero1)
numero1--;
console.log(numero1)

//negacion
var visible = true;
alert(!visible); // muestra "false" y no "true"
var cantidad = 0;
vacio = !cantidad //vacio = false
cantidad = 2;
vacio = !cantidad //vacio = false
var mensaje = "";
mensajeVacio = !mensaje //mensajeVacio = true
mensaje = "Bienvenido";
mensajeVacio = !mensaje //mensajeVacio = true


//ifs
var edad = 70
if(edad<3){
    alert("Eres un bebé")
}
else if(edad<12){
    alert("Eres un niño")
}
else if(edad<18){
    alert("Eres un adolecente")
}
else if(edad<60){
    alert("Eres un adulto")
}
else{
    alert("Eres un adulto mayor")
}

//bucles
var msj = "Hola"
for(var i = 0; i < 5; i++){
    console.log(i + " " +msj);
}
for(var i = 0; i < 7; i++){
    console.log("dia " + dias[i]);
}