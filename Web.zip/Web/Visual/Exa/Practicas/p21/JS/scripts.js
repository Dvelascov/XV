function setData()
{
  
    localStorage.user="user";
    localStorage.admin="admin";
    localStorage.password="123";
    // productos 
    // los mensajes
}
function validateUser(){
    if(localStorage.user==document.getElementById("login").value && localStorage.password==document.getElementById("password").value)
    alert("ir a funciones de usuario")
    else if(localStorage.admin==document.getElementById("login").value && localStorage.password==document.getElementById("password").value)
    alert("ir a funciones de admin")
    else
    alert("datos incorrectos")
    //go to dashboard admin
}