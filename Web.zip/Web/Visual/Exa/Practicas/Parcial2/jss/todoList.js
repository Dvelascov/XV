const input = document.querySelector("input");
const agregar = document.querySelector(".agregar");
const ul = document.querySelector("ul");
const empty = document.querySelector(".empty");

agregar.addEventListener("click", (e) => {
    e.preventDefault();
    const text = input.value;

    if (text !== "") {
        const li = document.createElement("li");
        const p = document.createElement("p");
        p.textContent = text;

        li.appendChild(p);
        li.appendChild(eliminarBtn());
        ul.appendChild(li);

        input.value = "";
        empty.style.display = "none";
    }
});

function eliminarBtn() {
    const eliminar = document.createElement("button");

    eliminar.textContent = "x";
    eliminar.className = "btn-delete";

    eliminar.addEventListener("click", (e) => {
        const item = e.target.parentElement;
        ul.removeChild(item);

        const items = document.querySelectorAll("li");

    });

    return eliminar;
}
