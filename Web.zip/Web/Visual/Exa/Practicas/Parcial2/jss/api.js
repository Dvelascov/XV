var request = new XMLHttpRequest();

var url = "http://dummy.restapiexample.com/api/v1/employees"

request.open('GET', url);

request.send();
request.onload()=function(){
    //var object =JSON.parse(request.response)
    console.log(JSON.parse(request.response))
};

