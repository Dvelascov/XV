var num1;
var num2;
var signo;


function entero(){

    var resultado = document.getElementById("resultado");
    var uno = document.getElementById('uno');
    var dos = document.getElementById('dos');
    var tres = document.getElementById('tres');
    var cuatro = document.getElementById('cuatro');
    var cinco = document.getElementById('cinco');
    var seis = document.getElementById('seis');
    var siete = document.getElementById('siete');
    var ocho = document.getElementById('ocho');
    var nueve = document.getElementById('nueve');
    var cero = document.getElementById('cero');
    var por = document.getElementById('por');
    var dividir = document.getElementById('dividir');
    var suma = document.getElementById('suma');
    var resta = document.getElementById('resta');
    var muestra = document.getElementById('muestra');
    var reset = document.getElementById('reset');
    var punto = document.getElementById('punto');

    uno.onclick = function(){
        resultado.textContent = resultado.textContent + "1";
    }
    dos.onclick = function(){
        resultado.textContent = resultado.textContent + "2";
    }
    tres.onclick = function(){
        resultado.textContent = resultado.textContent + "3";
    }
    cuatro.onclick = function(){
        resultado.textContent = resultado.textContent + "4";
    }
    cinco.onclick = function(){
        resultado.textContent = resultado.textContent + "5";
    }
    seis.onclick = function(){
        resultado.textContent = resultado.textContent + "6";
    }
    siete.onclick = function(){
        resultado.textContent = resultado.textContent + "7";
    }
    ocho.onclick = function(){
        resultado.textContent = resultado.textContent + "8";
    }
    nueve.onclick = function(){
        resultado.textContent = resultado.textContent + "9";
    }
    cero.onclick = function(){
        resultado.textContent = resultado.textContent + "0";
    }
    punto.onclick = function(){
        resultado.textContent = resultado.textContent + ".";
    }
    reset.onclick = function(){
        clean();
    }
    suma.onclick = function(){
        num1 = resultado.textContent;
        signo = "+";
        limpio();
    }
    resta.onclick = function(){
        num1 = resultado.textContent;
        signo = "-";
        limpio();
    }
    por.onclick = function(){
        num1 = resultado.textContent;
        signo = "*";
        limpio();
    }
    dividir.onclick = function(){
        num1 = resultado.textContent;
        signo = "/";
        limpio();
    }
    muestra.onclick = function(){
        num2 = resultado.textContent;
        go();
    }
}
function limpio(){
    resultado.textContent = "";
}
function clean(){
    resultado.textContent = "";
    num1 = 0;  
    num2 = 0; 
    signo = "";
}
function go(){

    var nr = 0;
    switch(signo){
        case "+":
            nr = parseFloat(num1) + parseFloat(num2);
            break;
        case "-":
            nr = parseFloat(num1) - parseFloat(num2);
            break;
        case "*":
            nr = parseFloat(num1) * parseFloat(num2);
            break;
        case "/":
            nr = parseFloat(num1) / parseFloat(num2);
            break;
    }
   
    clean();
    resultado.textContent = nr;


}
